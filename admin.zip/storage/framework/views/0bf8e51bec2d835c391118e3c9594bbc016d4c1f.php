<?php $__env->startSection('content'); ?>
<div class="row">

    <!-- DataTales Example -->
    <div class="col-xl-8">
        <!-- Account details card-->
        <div class="card mb-4">
            <div class="card-header">Add Category</div>
            <div class="card-body">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php if($message ?? ''): ?>
            <div class="alert alert-success"><?php echo e($message ?? ''); ?></div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(url('addCategory')); ?>">
                    <?php echo csrf_field(); ?>
                    <!-- Form Group (username)-->

                    <!-- Form Row-->
                    <div class="form-row">
                        <!-- Form Group (first name)-->
                        <div class="form-group col-md-6">
                            <label class="small mb-1"  for="inputFirstName">Category Name</label>
                            <input class="form-control" name="category" id="inputFirstName" type="text"
                                placeholder="Enter Category name" />
                        </div>

                    </div>
                    <!-- Save changes button-->
                    <input class="btn btn-primary" type="submit" value="Save"/>
                </form>



            </div>
        </div>
    </div>
</div>


<div class="row">

    <!-- DataTales Example -->
    <div class="col-xl-8">
        <!-- Account details card-->
        <div class="card mb-4">
            <div class="card-header">Categories</div>
            <div class="card-body">

                <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                          <tr>
                            <th>S.No</th>
                            <th>Category</th>
                          <th>Action</th>

                          </tr>
                        </thead>
                        <tfoot>
                          <tr>
                            <th>S.No</th>
                            <th>Category</th>
                          <th>Action</th>
                          </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($item->c_name); ?></td>
                          <td><a href="category/<?php echo e($item->c_id); ?>/edit" class="btn btn-primary">Edit</a> <a href="category/<?php echo e($item->c_id); ?>" class="btn btn-danger">Delete</a></td>

                          </tr>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                      </table>
                    </div>
                  </div>




            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\programfiles\www\laravel\adminPanel\resources\views/addCategory.blade.php ENDPATH**/ ?>