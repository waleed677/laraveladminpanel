<?php $__env->startSection('content'); ?>

<div class="row">

    <!-- DataTales Example -->
    <div class="col-xl-8">
        <!-- Account details card-->
        <div class="card mb-4">
            <div class="card-header">Account Details</div>

            <?php if(Session::has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('message')); ?>

            </div>
            <?php endif; ?>

            <div class="card-body">
                <form method="POST" action="update">
                    <?php echo csrf_field(); ?>
                    <!-- Form Group (username)-->

                    <!-- Form Row-->

                    <!-- Form Group (first name)-->
                    <div class="form-group col-md-6">
                        <label class="small mb-1" for="inputFirstName">Name</label>
                        <input class="form-control" name="name" id="inputFirstName" type="text"
                            placeholder="Enter your first name" value="<?php echo e($data->name); ?>" />
                    </div>



                    <!-- Form Group (email address)-->
                    <div class="form-group col-md-6">
                        <label class="small mb-1" for="inputEmailAddress">Email address</label>
                        <input class="form-control" name="email" id="inputEmailAddress" type="email"
                            placeholder="Enter your email address" value="<?php echo e($data->email); ?>" />
                    </div>
                    <!-- Save changes button-->
                    <input type="submit" name="submit" class="btn btn-primary" value="Update Profile" />
                </form>


                <hr>

                <h2> Change Password</h2>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <form method="POST" action="update">
                    <?php echo csrf_field(); ?>
                    <!-- Form Group (username)-->

                    <!-- Form Row-->

                    <!-- Form Group (first name)-->
                    <div class="form-group col-md-6">
                        <label class="small mb-1" for="inputFirstName">Password</label>
                        <input class="form-control" name="password" id="inputFirstName" type="password"
                            placeholder="Enter New Password" />
                    </div>



                    <!-- Form Group (email address)-->
                    <div class="form-group col-md-6">
                        <label class="small mb-1" for="inputEmailAddress">Confirm Password</label>
                        <input class="form-control" name="cpassword" id="inputEmailAddress" type="password"
                            placeholder="Enter Confirm Password" />
                    </div>
                    <!-- Save changes button-->
                    <input class="btn btn-primary" type="submit" value="Update Password" name="submit">
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\programfiles\www\laravel\adminPanel\resources\views/profile.blade.php ENDPATH**/ ?>