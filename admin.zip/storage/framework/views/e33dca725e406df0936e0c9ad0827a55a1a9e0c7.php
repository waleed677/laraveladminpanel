<footer class="sticky-footer bg-white">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright &copy; Your Website 2020</span>
      </div>
    </div>
  </footer>
<?php /**PATH G:\programfiles\www\laravel\adminPanel\resources\views/layout/partials/footer.blade.php ENDPATH**/ ?>