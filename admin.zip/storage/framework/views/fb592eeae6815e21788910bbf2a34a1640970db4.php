<?php $__env->startSection('content'); ?>
<div class="row">

    <!-- DataTales Example -->
    <div class="col-xl-8">
        <!-- Account details card-->
        <div class="card mb-4">
            <div class="card-header">Edit Category</div>
            <?php if(Session::has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('message')); ?>

            </div>
            <?php endif; ?>
            <div class="card-body">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php if($message ?? ''): ?>
            <div class="alert alert-success"><?php echo e($message ?? ''); ?></div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(url('updateCategory')); ?>">
                    <?php echo csrf_field(); ?>
                    <!-- Form Group (username)-->

                    <!-- Form Row-->
                <input type="hidden" name="id" value="<?php echo e($data->c_id); ?>" />

                    <!-- Form Group (first name)-->
                    <div class="form-group col-md-6">
                        <label class="small mb-1" for="inputFirstName">Category Name</label>
                        <input class="form-control" id="inputFirstName" type="text"
                    placeholder="Enter Title" name="cname" value="<?php echo e($data->c_name); ?>" />
                    </div>
                    <!-- Save changes button-->
                    <input class="btn btn-primary" type="submit" value="Update" name="submit">
                </form>



            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\programfiles\www\laravel\adminPanel\resources\views/editCategory.blade.php ENDPATH**/ ?>